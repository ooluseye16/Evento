class TimeRemaining {
  String days;
  String hrs;
  String mins;
  String secs;

  TimeRemaining({this.days, this.hrs, this.mins, this.secs});
}
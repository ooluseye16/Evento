// GENERATED CODE - DO NOT MODIFY BY HAND

// ignore_for_file: camel_case_types

import 'dart:typed_data';

import 'package:objectbox/flatbuffers/flat_buffers.dart' as fb;
import 'package:objectbox/internal.dart'; // generated code can access "internal" functionality
import 'package:objectbox/objectbox.dart';
import 'package:objectbox_flutter_libs/objectbox_flutter_libs.dart';

import 'entities/entities.dart';

export 'package:objectbox/objectbox.dart'; // so that callers only have to import this file

final _entities = <ModelEntity>[
  ModelEntity(
      id: const IdUid(1, 8367832973380579416),
      name: 'Event',
      lastPropertyId: const IdUid(7, 4309776540447583407),
      flags: 0,
      properties: <ModelProperty>[
        ModelProperty(
            id: const IdUid(1, 6654651924725546957),
            name: 'id',
            type: 6,
            flags: 1),
        ModelProperty(
            id: const IdUid(2, 3881597433514336175),
            name: 'title',
            type: 9,
            flags: 0),
        ModelProperty(
            id: const IdUid(3, 4371369758684459858),
            name: 'date',
            type: 10,
            flags: 0),
        ModelProperty(
            id: const IdUid(4, 3245282932286191696),
            name: 'imagePath',
            type: 9,
            flags: 0),
        ModelProperty(
            id: const IdUid(5, 4949432916799053593),
            name: 'repeat',
            type: 9,
            flags: 0),
        ModelProperty(
            id: const IdUid(6, 8422396586973637833),
            name: 'note',
            type: 9,
            flags: 0),
        ModelProperty(
            id: const IdUid(7, 4309776540447583407),
            name: 'song',
            type: 9,
            flags: 0)
      ],
      relations: <ModelRelation>[],
      backlinks: <ModelBacklink>[])
];

/// Open an ObjectBox store with the model declared in this file.
Future<Store> openStore(
        {String directory,
        int maxDBSizeInKB,
        int fileMode,
        int maxReaders,
        bool queriesCaseSensitiveDefault = true,
        String macosApplicationGroup}) async =>
    Store(getObjectBoxModel(),
        directory: directory ?? (await defaultStoreDirectory()).path,
        maxDBSizeInKB: maxDBSizeInKB,
        fileMode: fileMode,
        maxReaders: maxReaders,
        queriesCaseSensitiveDefault: queriesCaseSensitiveDefault,
        macosApplicationGroup: macosApplicationGroup);

/// ObjectBox model definition, pass it to [Store] - Store(getObjectBoxModel())
ModelDefinition getObjectBoxModel() {
  final model = ModelInfo(
      entities: _entities,
      lastEntityId: const IdUid(1, 8367832973380579416),
      lastIndexId: const IdUid(0, 0),
      lastRelationId: const IdUid(0, 0),
      lastSequenceId: const IdUid(0, 0),
      retiredEntityUids: const [],
      retiredIndexUids: const [],
      retiredPropertyUids: const [],
      retiredRelationUids: const [],
      modelVersion: 5,
      modelVersionParserMinimum: 5,
      version: 1);

  final bindings = <Type, EntityDefinition>{
    Event: EntityDefinition<Event>(
        model: _entities[0],
        toOneRelations: (Event object) => [],
        toManyRelations: (Event object) => {},
        getId: (Event object) => object.id,
        setId: (Event object, int id) {
          object.id = id;
        },
        objectToFB: (Event object, fb.Builder fbb) {
          final titleOffset =
              object.title == null ? null : fbb.writeString(object.title);
          final imagePathOffset = object.imagePath == null
              ? null
              : fbb.writeString(object.imagePath);
          final repeatOffset =
              object.repeat == null ? null : fbb.writeString(object.repeat);
          final noteOffset =
              object.note == null ? null : fbb.writeString(object.note);
          final songOffset =
              object.song == null ? null : fbb.writeString(object.song);
          fbb.startTable(8);
          fbb.addInt64(0, object.id ?? 0);
          fbb.addOffset(1, titleOffset);
          fbb.addInt64(2, object.date?.millisecondsSinceEpoch);
          fbb.addOffset(3, imagePathOffset);
          fbb.addOffset(4, repeatOffset);
          fbb.addOffset(5, noteOffset);
          fbb.addOffset(6, songOffset);
          fbb.finish(fbb.endTable());
          return object.id ?? 0;
        },
        objectFromFB: (Store store, ByteData fbData) {
          final buffer = fb.BufferContext(fbData);
          final rootOffset = buffer.derefObject(0);
          final dateValue =
              const fb.Int64Reader().vTableGetNullable(buffer, rootOffset, 8);
          final object = Event(
              id: const fb.Int64Reader()
                  .vTableGetNullable(buffer, rootOffset, 4),
              title: const fb.StringReader()
                  .vTableGetNullable(buffer, rootOffset, 6),
              date: dateValue == null
                  ? null
                  : DateTime.fromMillisecondsSinceEpoch(dateValue),
              imagePath: const fb.StringReader()
                  .vTableGetNullable(buffer, rootOffset, 10),
              repeat: const fb.StringReader()
                  .vTableGetNullable(buffer, rootOffset, 12),
              note: const fb.StringReader()
                  .vTableGetNullable(buffer, rootOffset, 14),
              song: const fb.StringReader()
                  .vTableGetNullable(buffer, rootOffset, 16));

          return object;
        })
  };

  return ModelDefinition(model, bindings);
}

/// [Event] entity fields to define ObjectBox queries.
class Event_ {
  /// see [Event.id]
  static final id = QueryIntegerProperty<Event>(_entities[0].properties[0]);

  /// see [Event.title]
  static final title = QueryStringProperty<Event>(_entities[0].properties[1]);

  /// see [Event.date]
  static final date = QueryIntegerProperty<Event>(_entities[0].properties[2]);

  /// see [Event.imagePath]
  static final imagePath =
      QueryStringProperty<Event>(_entities[0].properties[3]);

  /// see [Event.repeat]
  static final repeat = QueryStringProperty<Event>(_entities[0].properties[4]);

  /// see [Event.note]
  static final note = QueryStringProperty<Event>(_entities[0].properties[5]);

  /// see [Event.song]
  static final song = QueryStringProperty<Event>(_entities[0].properties[6]);
}

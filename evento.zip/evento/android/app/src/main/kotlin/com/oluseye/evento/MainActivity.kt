package com.oluseye.evento

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

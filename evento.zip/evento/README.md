# Evento

A  Flutter application that displays time remaining to events preset or created by users.

